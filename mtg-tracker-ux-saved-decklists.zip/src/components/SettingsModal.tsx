import { useEffect, useState } from "react"
import { X } from "lucide-react"
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query"
import { fetchCurrentProfile, updateUsername } from "../lib/data"

type Density = "comfortable" | "compact"

export function applySavedDensity() {
  const density = (localStorage.getItem("tracker-density") || "comfortable") as Density
  document.documentElement.dataset.density = density
}

export function SettingsModal({ onClose,desktopPanel=false,onDesktopPanelChange }: { onClose: () => void;desktopPanel?:boolean;onDesktopPanelChange?:(value:boolean)=>void }) {
  const qc = useQueryClient()
  const profile = useQuery({ queryKey: ["profile"], queryFn: fetchCurrentProfile })
  const [density, setDensity] = useState<Density>(
    (localStorage.getItem("tracker-density") || "comfortable") as Density,
  )
  const [username, setUsername] = useState("")

  useEffect(() => {
    if (profile.data?.username != null) setUsername(profile.data.username)
  }, [profile.data])

  useEffect(() => {
    document.documentElement.dataset.density = density
    localStorage.setItem("tracker-density", density)
  }, [density])

  const saveUsername = useMutation({
    mutationFn: () => updateUsername(username),
    onSuccess: async () => {
      await qc.invalidateQueries({ queryKey: ["profile"] })
    },
  })

  return (
    <div className="modalBackdrop" onMouseDown={onClose}>
      <section className="modal smallModal" onMouseDown={(event) => event.stopPropagation()}>
        <header className="modalHeader">
          <div>
            <h2>Settings</h2>
            <p>Account and local tracker preferences.</p>
          </div>
          <button className="iconButton" onClick={onClose}><X size={18} /></button>
        </header>

        <div className="modalBody">
          <label>
            Username
            <input
              value={username}
              onChange={(event) => setUsername(event.target.value)}
              placeholder="username"
            />
          </label>
          <button
            className="secondaryButton"
            disabled={!username.trim() || saveUsername.isPending}
            onClick={() => saveUsername.mutate()}
          >
            {saveUsername.isPending ? "Saving..." : "Save username"}
          </button>
          {saveUsername.error && <p className="errorText">{saveUsername.error.message}</p>}

          <label>
            Card grid density
            <select value={density} onChange={(event) => setDensity(event.target.value as Density)}>
              <option value="comfortable">Comfortable</option>
              <option value="compact">Compact</option>
            </select>
          </label>
          <p className="settingsHint">Grid density is saved only in this browser.</p>
          <label className="checkRow"><input type="checkbox" checked={desktopPanel} onChange={e=>onDesktopPanelChange?.(e.target.checked)}/> Open card details in a desktop side panel</label>
          <p className="settingsHint">Saved per account. Phones keep the bottom-sheet layout.</p>
        </div>
      </section>
    </div>
  )
}

